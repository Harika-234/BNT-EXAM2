import React, { useState } from 'react';

function ItemList() {
  const [items, setItems] = useState(["Apple", "Banana", "Orange"]);

  const handleDelete = (indexToRemove) => {
    const updatedItems = items.filter((_, index) => index !== indexToRemove);
    setItems(updatedItems);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Fruit List</h2>
      <ul>
        {items.map((item, index) => (
          <li key={index} style={{ marginBottom: '10px' }}>
            {item}
            <button 
              onClick={() => handleDelete(index)} 
              style={{ marginLeft: '10px', color: 'white', background: 'red', border: 'none', padding: '5px 10px' }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
      {items.length === 0 && <p>No items left.</p>}
    </div>
  );
}

export default ItemList;
