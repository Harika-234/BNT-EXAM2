import React from 'react';
import Counter from './Counter';
import GreetingToggle from './Greeting Tool';
import ParentComponent from './ParentComponent';
import GrandParent from './GrandParent';
import NameList from './NameList';
import CheckboxMessage  from './CheckboxMessage';
import ControlledInput from './ControlledInput';
import LoginForm from './loginform';
import ItemList from './ItemList';
import TodoApp from './TodoApp';
import CounterReset from './CounterReset';




function App() {
  
  return (
    <div >
      <Counter />
      <GreetingToggle />
      <ParentComponent />
      <GrandParent />
      <NameList />
      <CheckboxMessage/>
      <ControlledInput/>
      <LoginForm/>
      <ItemList/>
      <TodoApp/>
      <CounterReset/>
      
      
    </div>
  );
}

export default App;











  














