import React from 'react';

function ChildComponent({ greeting }) {
  return (
    <div>
      <h3>Child Component</h3>
      <p>{greeting}</p>
    </div>
  );
}

export default ChildComponent;
