import React, { useState } from 'react';

function CounterReset() {
  const [count, setCount] = useState(0);

  const handleClick = () => {
    setCount(prev => (prev + 1 === 10 ? 0 : prev + 1));
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px'}}>
      <h2>Count: {count}</h2>
      <button onClick={handleClick} style={{ padding: '10px 20px' }}>
        Increment
      </button>
    </div>
  );
}
export default CounterReset;
