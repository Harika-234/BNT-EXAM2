import React from 'react';
import Child from './Child';

function Parent({ message }) {
  return (
    <div>
      <h3>Parent Component</h3>
      <Child message={message} />
    </div>
  );
}

export default Parent;
