import React, { useState } from 'react';

function TodoApp() {
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState("");

  const handleAdd = () => {
    if (newTodo.trim() !== "") {
      setTodos([...todos, newTodo]);
      setNewTodo("");
    }
  };

  const handleDelete = (indexToRemove) => {
    const updatedTodos = todos.filter((_, index) => index !== indexToRemove);
    setTodos(updatedTodos);
  };

  return (
    <div style={{ maxWidth: '400px', margin: '40px auto', textAlign: 'center' }}>
      <h2>Todo App</h2>
      <input
        type="text"
        placeholder="Enter a todo"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
        style={{ padding: '8px', width: '70%' }}
      />
      <button onClick={handleAdd} style={{ padding: '8px 12px', marginLeft: '5px' }}>
        Add
      </button>

      <ul style={{ marginTop: '20px', listStyle: 'none', padding: 0 }}>
        {todos.map((todo, index) => (
          <li key={index} style={{ marginBottom: '10px' }}>
            {todo}
            <button
              onClick={() => handleDelete(index)}
              style={{
                marginLeft: '10px',
                padding: '4px 8px',
                background: 'red',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
              }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoApp;
