import React, { useState } from 'react';

function GreetingToggle() {
  const [message, setMessage] = useState("Hello");

  const toggleMessage = () => {
    setMessage(prev => prev === "Hello" ? "Welcome Back" : "Hello");
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>{message}</h2>
      <button onClick={toggleMessage}>Toggle</button>
    </div>
  );
}

export default GreetingToggle;
