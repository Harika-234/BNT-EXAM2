import React from 'react';
import Parent from './Parent';

function GrandParent() {
  const message = "Hello from GrandParent";

  return (
    <div>
      <h2>GrandParent Component</h2>
      <Parent message={message} />
    </div>
  );
}

export default GrandParent;
