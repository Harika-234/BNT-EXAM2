import React, { useState } from 'react';

function CheckboxMessage() {
  const [isChecked, setIsChecked] = useState(false);

  const handleCheckboxChange = () => {
    setIsChecked(!isChecked);
  };

  return (
    <div style={{ marginTop: '50px', textAlign: 'center' }}>
      <input 
        type="checkbox" 
        onChange={handleCheckboxChange}
        checked={isChecked}
      />
      <label> Check me!</label>

      {isChecked && <p>You checked the box!</p>}
    </div>
  );
}

export default CheckboxMessage;
